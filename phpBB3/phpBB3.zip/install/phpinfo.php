<?php

phpinfo();

?>